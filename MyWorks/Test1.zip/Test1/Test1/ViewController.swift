//
//  ViewController.swift
//  Test1
//
//  Created by Tehila Amran on 16/06/2020.
//  Copyright © 2020 None. All rights reserved.
//

import UIKit
import AVFoundation
import MobileCoreServices


class BottomView: UIView {
    
    @IBOutlet weak var leftImgView: UIImageView!
    @IBOutlet weak var rightImgView: UIImageView!
    @IBOutlet weak var capture: UIButton!
    
    func convigure(images: [UIImage?]) {
        
        self.isHidden = false
        self.leftImgView.image = images[0]
         self.rightImgView.image = images[1]
    }
    
    
    
}

class ViewController: UIViewController {
    
    
    
    let sourceUrl = "https://y0.com/cdn2/test/images.json?f"
    lazy var picker = UIImagePickerController()
    @IBOutlet weak var bottomView: BottomView!{
        didSet{
            self.bottomView.isHidden = true
        }
    }
    
    
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func startTapped(_ sender: UIButton) {
        
        sender.isUserInteractionEnabled = false
        
        self.spinner.stopAnimating()
        self.spinner.isHidden = false
        
        let provider = SourceProvider.sharedProvider
        provider.downloadSource(url: sourceUrl) { [weak self] (finished) in
            
            guard let bself = self else{
                return
            }
            DispatchQueue.main.async {
                
                
                if finished == true {
                    bself.spinner.stopAnimating()
                    sender.isUserInteractionEnabled = true
                    bself.showCamera()
                    
                }
                
                
            }
            
        }
    }
    
    //MARK: -- IBAction
    
    @IBAction func captureTapped(_ sender: UIButton) {
        
        
    }
    
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    
    
    private func checkPermission(callback: @escaping ( (_ allowed: Bool) -> ())) {
        
        let cameraMediaType = AVMediaType.video
        let cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: cameraMediaType)
        
        switch cameraAuthorizationStatus {
        case .denied:
            
            callback (false)
        case .authorized:
            callback (true)
        case .restricted:
            callback (false)
            
        case .notDetermined:
            // Prompting user for the permission to use the camera.
            AVCaptureDevice.requestAccess(for: cameraMediaType) { granted in
                if granted {
                    print("Granted access to \(cameraMediaType)")
                    callback (true)
                } else {
                    print("Denied access to \(cameraMediaType)")
                    callback (false)
                }
            }
        }
        
    }
    
    func showCamera()  {
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera){
            
            
            self.checkPermission { (allowed) in
                
                
                if allowed == true {
                    
                    self.picker.delegate = self
                    self.picker.sourceType = .camera
                    self.picker.mediaTypes = [kUTTypeImage as String]
                    self.picker.allowsEditing = true
                    self.present(self.picker, animated: true) {
                        
                        self.bottomView.convigure(images: SourceProvider.sharedProvider.images)
                        let frame = self.picker.view.frame
                        
                        self.bottomView.frame = CGRect(x: 0, y: frame.size.height - self.bottomView.frame.size.height, width: frame.size.width, height: self.bottomView.frame.size.height)
                       //  self.picker.view.addSubview(self.bottomView)
                        self.picker.cameraOverlayView = self.bottomView
 
                    }
 
                    
                }else {
                    
                    //show alert
                    
                }
            }
            
            // ask permisions
        }
        
    }
}

